from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'  # Using SQLite for simplicity
db = SQLAlchemy(app)

class FormData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), nullable=False)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    name = request.form['name']
    email = request.form['email']

    # Store the data in the database
    form_data = FormData(name=name, email=email)
    db.session.add(form_data)
    db.session.commit()

    return redirect(url_for('home'))

if __name__ == '__main__':
    db.create_all()  # Create tables before running the app
    app.run(debug=True)

