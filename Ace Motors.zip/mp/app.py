from flask import Flask, render_template, request, url_for

app = Flask(__name__)

@app.route('/')
def booknow():
    return render_template('booknow.html')

@app.route('/submit', methods=['POST'])
def submit():
    name = request.form['name']
    email = request.form['email']

    # Print the collected data on the server side (you might want to store it in a database)
    print(f"Received data: Name - {name}, Email - {email}")

    return "Data received successfully!"

if __name__ == '__main__':
    app.run(debug=True)

